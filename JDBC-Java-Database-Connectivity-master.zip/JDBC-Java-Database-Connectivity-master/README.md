# JDBC-Java-Database-Connectivity
This repo contains demonstration of Simple Banking System with Java Database Connectivity (JDBC)
